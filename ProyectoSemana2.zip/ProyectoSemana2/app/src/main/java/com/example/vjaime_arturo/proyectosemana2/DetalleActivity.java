package com.example.vjaime_arturo.proyectosemana2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class DetalleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle);

        Bundle datos = getIntent().getExtras();

        TextView NombreCompleto = (TextView)findViewById(R.id.tvDNombre);
        String sNombreCompleto = datos.getString(getResources().getString(R.string.nombreCompleto));
        NombreCompleto.setText(sNombreCompleto);

        TextView FechaNacimiento = (TextView)findViewById(R.id.tvDFechaNacimiento);
        FechaNacimiento.setText(datos.getString(getResources().getString(R.string.fechaNacimiento)));

        TextView EMail = (TextView)findViewById(R.id.tvDEMail);
        EMail.setText(datos.getString(getResources().getString(R.string.eMail)));

        TextView Telefono = (TextView)findViewById(R.id.tvDTelefono);
        Telefono.setText(datos.getString(getResources().getString(R.string.telefono)));

        TextView Descripcion = (TextView)findViewById(R.id.tvDDescripcion);
        Descripcion.setText(datos.getString(getResources().getString(R.string.descripcion)));

        Button btnAceptar = (Button)findViewById(R.id.botonAceptar);
        btnAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetalleActivity.this, MainActivity.class);

                startActivity(intent);
                finish();
            }
        });
        Button btnEditar = (Button)findViewById(R.id.botonEditar);
        btnEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetalleActivity.this, MainActivity.class);

                TextView nombre = (TextView) findViewById(R.id.tvDNombre);
                String sNombre = nombre.getText().toString();
                intent.putExtra(getResources().getString(R.string.nombreCompleto), sNombre);

                TextView fecha = (TextView) findViewById(R.id.tvDFechaNacimiento);
                String sFecha = fecha.getText().toString();
                intent.putExtra(getResources().getString(R.string.fechaNacimiento), sFecha);

                TextView telefono = (TextView) findViewById(R.id.tvDTelefono);
                String sTelefono = telefono.getText().toString();
                intent.putExtra(getResources().getString(R.string.telefono), sTelefono);

                TextView eMail = (TextView) findViewById(R.id.tvDEMail);
                String sEMail = eMail.getText().toString();
                intent.putExtra(getResources().getString(R.string.eMail), sEMail);

                TextView descripcion = (TextView) findViewById(R.id.tvDDescripcion);
                String sDescripcion = descripcion.getText().toString();
                intent.putExtra(getResources().getString(R.string.descripcion), sDescripcion);

                startActivity(intent);
                finish();
            }
        });
    }
}
