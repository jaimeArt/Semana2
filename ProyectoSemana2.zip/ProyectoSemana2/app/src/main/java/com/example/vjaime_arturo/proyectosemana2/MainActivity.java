package com.example.vjaime_arturo.proyectosemana2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.TextView;
import android.widget.DatePicker;
import android.app.DialogFragment;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Bundle datos = getIntent().getExtras();
        if(datos != null){
        EditText NombreCompleto = (EditText) findViewById(R.id.etNombreCompleto);
        String sNombreCompleto = datos.getString(getResources().getString(R.string.nombreCompleto));
        NombreCompleto.setText(sNombreCompleto);

        EditText FechaNacimiento = (EditText) findViewById(R.id.etFechaNacimiento);
        FechaNacimiento.setText(datos.getString(getResources().getString(R.string.fechaNacimiento)));

        EditText EMail = (EditText) findViewById(R.id.etEmail);
        EMail.setText(datos.getString(getResources().getString(R.string.eMail)));

        EditText Telefono = (EditText) findViewById(R.id.etTelefono);
        Telefono.setText(datos.getString(getResources().getString(R.string.telefono)));

        EditText Descripcion = (EditText) findViewById(R.id.etDescripcion);
        Descripcion.setText(datos.getString(getResources().getString(R.string.descripcion)));
       }
        Button btn = (Button)findViewById(R.id.botonAceptar);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, DetalleActivity.class);

                EditText nombre = (EditText) findViewById(R.id.etNombreCompleto);
                String sNombre = nombre.getText().toString();
                intent.putExtra(getResources().getString(R.string.nombreCompleto), sNombre);

                EditText fecha = (EditText) findViewById(R.id.etFechaNacimiento);
                String sFecha = fecha.getText().toString();
                intent.putExtra(getResources().getString(R.string.fechaNacimiento), sFecha);

                EditText telefono = (EditText) findViewById(R.id.etTelefono);
                String sTelefono = telefono.getText().toString();
                intent.putExtra(getResources().getString(R.string.telefono), sTelefono);

                EditText eMail = (EditText) findViewById(R.id.etEmail);
                String sEMail = eMail.getText().toString();
                intent.putExtra(getResources().getString(R.string.eMail), sEMail);

                EditText descripcion = (EditText) findViewById(R.id.etDescripcion);
                String sDescripcion = descripcion.getText().toString();
                intent.putExtra(getResources().getString(R.string.descripcion), sDescripcion);

                startActivity(intent);
                finish();

            }
        });
    }

 /*   public void showDatePickerDialog(View v) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }*/

}
